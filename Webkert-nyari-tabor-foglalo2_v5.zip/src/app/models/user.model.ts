// models/user.model.ts
export enum UserType {
    SZULO = 'SZULO',
    FIATAL = 'FIATAL',
    PEDAGOGUS = 'PEDAGOGUS',
    ONKENTES = 'ONKENTES',
    ADMIN = 'ADMIN'
  }
  
  export interface User {
    id: string;
    email: string;
    nev: string;
    userType: UserType;
    telefonszam: string;
    createdAt: Date;
  }
  
  export interface SzuloUser extends User {
    gyermekek: Gyermek[];
  }
  
  export interface FiatalUser extends User {
    szuletesiDatum: Date;
    szuloiBeleegyezes?: string; // Dokumentum URL
  }
  
  export interface PedagogusUser extends User {
    iskolaNeve: string;
    pozicio: string;
  }
  
  export interface OnkentesUser extends User {
    szuletesiDatum: Date;
    onkentesTipus: string;
    tapasztalat: string;
  }
  
  export interface AdminUser extends User {
    jogosultsagok: string[];
  }
  
  export interface Gyermek {
    id: string;
    nev: string;
    szuletesiDatum: Date;
    megjegyzes?: string;
  }
  
  