import { Component } from '@angular/core';

@Component({
  selector: 'app-camps',
  imports: [],
  templateUrl: './my-camps.component.html',
  styleUrl: './my-camps.component.css'
})
export class MyCampsComponent {

}
