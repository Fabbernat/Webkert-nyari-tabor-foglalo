import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MyCampsComponent } from './my-camps.component';

describe('MyCampsComponent', () => {
  let component: MyCampsComponent;
  let fixture: ComponentFixture<MyCampsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MyCampsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MyCampsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
