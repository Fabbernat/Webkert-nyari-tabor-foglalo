import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent {
  title: string = 'Nyári tábor foglaló alkalmazás';

  a: any = 0;
  constructor(){
    console.log(this.a);
    
  };

  myFunction(){};
}
