.
├── angular.json
├── package.json
├── package-lock.json
├── public
│   └── favicon.ico
├── README.md
├── src
│   ├── app
│   │   ├── app.component.html
│   │   ├── app.component.scss
│   │   ├── app.component.spec.ts
│   │   ├── app.component.ts
│   │   ├── app.config.ts
│   │   ├── app.routes.ts
│   │   ├── core
│   │   │   ├── components
│   │   │   │   ├── footer
│   │   │   │   │   ├── footer.component.html
│   │   │   │   │   ├── footer.component.scss
│   │   │   │   │   ├── footer.component.spec.ts
│   │   │   │   │   └── footer.component.ts
│   │   │   │   ├── header
│   │   │   │   │   ├── header.component.html
│   │   │   │   │   ├── header.component.scss
│   │   │   │   │   ├── header.component.spec.ts
│   │   │   │   │   └── header.component.ts
│   │   │   │   └── navigation
│   │   │   │       ├── navigation.component.html
│   │   │   │       ├── navigation.component.scss
│   │   │   │       ├── navigation.component.spec.ts
│   │   │   │       └── navigation.component.ts
│   │   │   ├── core.module.ts
│   │   │   ├── guards
│   │   │   │   ├── admin.guard.spec.ts
│   │   │   │   ├── admin.guard.ts
│   │   │   │   ├── auth.guard.spec.ts
│   │   │   │   ├── auth.guard.ts
│   │   │   │   ├── user-type-selection.guard.spec.ts
│   │   │   │   └── user-type-selection.guard.ts
│   │   │   └── services
│   │   │       ├── auth.service.spec.ts
│   │   │       ├── auth.service.ts
│   │   │       ├── camp.service.spec.ts
│   │   │       ├── camp.service.ts
│   │   │       ├── user.service.spec.ts
│   │   │       └── user.service.ts
│   │   ├── features
│   │   │   ├── admin
│   │   │   │   ├── admin.module.ts
│   │   │   │   ├── admin-routing.module.ts
│   │   │   │   └── components
│   │   │   │       ├── camp-location-manager
│   │   │   │       │   ├── camp-location-manager.component.html
│   │   │   │       │   ├── camp-location-manager.component.scss
│   │   │   │       │   ├── camp-location-manager.component.spec.ts
│   │   │   │       │   └── camp-location-manager.component.ts
│   │   │   │       ├── stats-dashboard
│   │   │   │       │   ├── stats-dashboard.component.html
│   │   │   │       │   ├── stats-dashboard.component.scss
│   │   │   │       │   ├── stats-dashboard.component.spec.ts
│   │   │   │       │   └── stats-dashboard.component.ts
│   │   │   │       └── user-manager
│   │   │   │           ├── user-manager.component.html
│   │   │   │           ├── user-manager.component.scss
│   │   │   │           ├── user-manager.component.spec.ts
│   │   │   │           └── user-manager.component.ts
│   │   │   ├── auth
│   │   │   │   ├── auth.module.ts
│   │   │   │   ├── auth-routing.module.ts
│   │   │   │   └── components
│   │   │   │       ├── login
│   │   │   │       │   ├── login.component.html
│   │   │   │       │   ├── login.component.scss
│   │   │   │       │   ├── login.component.spec.ts
│   │   │   │       │   └── login.component.ts
│   │   │   │       ├── register
│   │   │   │       │   ├── register.component.html
│   │   │   │       │   ├── register.component.scss
│   │   │   │       │   ├── register.component.spec.ts
│   │   │   │       │   └── register.component.ts
│   │   │   │       └── user-type-selection
│   │   │   │           ├── user-type-selection.component.html
│   │   │   │           ├── user-type-selection.component.scss
│   │   │   │           ├── user-type-selection.component.spec.ts
│   │   │   │           └── user-type-selection.component.ts
│   │   │   ├── camps
│   │   │   │   ├── camps.module.ts
│   │   │   │   ├── camps-routing.module.ts
│   │   │   │   └── components
│   │   │   │       ├── camp-details
│   │   │   │       │   ├── camp-details.component.html
│   │   │   │       │   ├── camp-details.component.scss
│   │   │   │       │   ├── camp-details.component.spec.ts
│   │   │   │       │   └── camp-details.component.ts
│   │   │   │       ├── camp-list
│   │   │   │       │   ├── camp-list.component.html
│   │   │   │       │   ├── camp-list.component.scss
│   │   │   │       │   ├── camp-list.component.spec.ts
│   │   │   │       │   └── camp-list.component.ts
│   │   │   │       ├── camp-registration
│   │   │   │       │   ├── camp-registration.component.html
│   │   │   │       │   ├── camp-registration.component.scss
│   │   │   │       │   ├── camp-registration.component.spec.ts
│   │   │   │       │   └── camp-registration.component.ts
│   │   │   │       └── create-camp
│   │   │   │           ├── create-camp.component.html
│   │   │   │           ├── create-camp.component.scss
│   │   │   │           ├── create-camp.component.spec.ts
│   │   │   │           └── create-camp.component.ts
│   │   │   ├── home
│   │   │   │   ├── components
│   │   │   │   │   ├── camp-types
│   │   │   │   │   │   ├── camp-types.component.html
│   │   │   │   │   │   ├── camp-types.component.scss
│   │   │   │   │   │   ├── camp-types.component.spec.ts
│   │   │   │   │   │   └── camp-types.component.ts
│   │   │   │   │   ├── featured-camps
│   │   │   │   │   │   ├── featured-camps.component.html
│   │   │   │   │   │   ├── featured-camps.component.scss
│   │   │   │   │   │   ├── featured-camps.component.spec.ts
│   │   │   │   │   │   └── featured-camps.component.ts
│   │   │   │   │   └── hero
│   │   │   │   │       ├── hero.component.html
│   │   │   │   │       ├── hero.component.scss
│   │   │   │   │       ├── hero.component.spec.ts
│   │   │   │   │       └── hero.component.ts
│   │   │   │   ├── home.module.ts
│   │   │   │   └── home-routing.module.ts
│   │   │   └── profile
│   │   │       ├── components
│   │   │       │   ├── edit-profile
│   │   │       │   │   ├── edit-profile.component.html
│   │   │       │   │   ├── edit-profile.component.scss
│   │   │       │   │   ├── edit-profile.component.spec.ts
│   │   │       │   │   └── edit-profile.component.ts
│   │   │       │   ├── my-registrations
│   │   │       │   │   ├── my-registrations.component.html
│   │   │       │   │   ├── my-registrations.component.scss
│   │   │       │   │   ├── my-registrations.component.spec.ts
│   │   │       │   │   └── my-registrations.component.ts
│   │   │       │   └── user-profile
│   │   │       │       ├── user-profile.component.html
│   │   │       │       ├── user-profile.component.scss
│   │   │       │       ├── user-profile.component.spec.ts
│   │   │       │       └── user-profile.component.ts
│   │   │       ├── profile.module.ts
│   │   │       └── profile-routing.module.ts
│   │   └── shared
│   │       ├── models
│   │       │   ├── camp-location.ts
│   │       │   ├── camp.ts
│   │       │   └── user.ts
│   │       └── shared.module.ts
│   ├── index.html
│   ├── main.ts
│   └── styles.scss
├── tree.md
├── tsconfig.app.json
├── tsconfig.json
└── tsconfig.spec.json

40 directories, 121 files
