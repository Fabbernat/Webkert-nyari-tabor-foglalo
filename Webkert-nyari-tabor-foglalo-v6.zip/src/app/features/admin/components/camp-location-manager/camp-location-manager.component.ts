import { Component } from '@angular/core';

@Component({
  selector: 'app-camp-location-manager',
  imports: [],
  templateUrl: './camp-location-manager.component.html',
  styleUrl: './camp-location-manager.component.scss'
})
export class CampLocationManagerComponent {

}
