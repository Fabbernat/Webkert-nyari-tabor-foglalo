import { Component } from '@angular/core';

@Component({
  selector: 'app-stats-dashboard',
  imports: [],
  templateUrl: './stats-dashboard.component.html',
  styleUrl: './stats-dashboard.component.scss'
})
export class StatsDashboardComponent {

}
