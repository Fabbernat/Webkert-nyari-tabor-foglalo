import { Component } from '@angular/core';

@Component({
  selector: 'app-user-manager',
  imports: [],
  templateUrl: './user-manager.component.html',
  styleUrl: './user-manager.component.scss'
})
export class UserManagerComponent {

}
