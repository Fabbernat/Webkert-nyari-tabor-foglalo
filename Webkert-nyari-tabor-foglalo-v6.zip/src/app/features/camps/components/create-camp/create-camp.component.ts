import { Component } from '@angular/core';

@Component({
  selector: 'app-create-camp',
  imports: [],
  templateUrl: './create-camp.component.html',
  styleUrl: './create-camp.component.scss'
})
export class CreateCampComponent {

}
