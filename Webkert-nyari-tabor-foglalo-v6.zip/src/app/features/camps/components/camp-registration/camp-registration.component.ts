import { Component } from '@angular/core';

@Component({
  selector: 'app-camp-registration',
  imports: [],
  templateUrl: './camp-registration.component.html',
  styleUrl: './camp-registration.component.scss'
})
export class CampRegistrationComponent {

}
