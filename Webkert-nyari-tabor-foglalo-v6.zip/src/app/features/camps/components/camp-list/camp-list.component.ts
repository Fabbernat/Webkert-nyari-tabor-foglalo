import { Component } from '@angular/core';

@Component({
  selector: 'app-camp-list',
  imports: [],
  templateUrl: './camp-list.component.html',
  styleUrl: './camp-list.component.scss'
})
export class CampListComponent {

}
