import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CampsRoutingModule } from './camps-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    CampsRoutingModule
  ]
})
export class CampsModule { }
