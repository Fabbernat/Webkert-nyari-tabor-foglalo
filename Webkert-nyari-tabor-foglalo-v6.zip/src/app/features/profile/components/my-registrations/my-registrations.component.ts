import { Component } from '@angular/core';

@Component({
  selector: 'app-my-registrations',
  imports: [],
  templateUrl: './my-registrations.component.html',
  styleUrl: './my-registrations.component.scss'
})
export class MyRegistrationsComponent {

}
