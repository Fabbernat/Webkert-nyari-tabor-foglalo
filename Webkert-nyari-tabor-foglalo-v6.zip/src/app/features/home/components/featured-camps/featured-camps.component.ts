import { Component } from '@angular/core';

@Component({
  selector: 'app-featured-camps',
  imports: [],
  templateUrl: './featured-camps.component.html',
  styleUrl: './featured-camps.component.scss'
})
export class FeaturedCampsComponent {

}
