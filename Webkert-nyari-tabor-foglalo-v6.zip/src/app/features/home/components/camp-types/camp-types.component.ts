import { Component } from '@angular/core';

@Component({
  selector: 'app-camp-types',
  imports: [],
  templateUrl: './camp-types.component.html',
  styleUrl: './camp-types.component.scss'
})
export class CampTypesComponent {

}
